const mongoose = require('mongoose');

const saleItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
  },
  productCode: {
    type: String,
    trim: true,
  },
  productName: {
    type: String,
    required: true,
  },
  quantity: {
    type: Number,
    required: [true, 'Quantity is required'],
    min: [1, 'Quantity must be at least 1'],
  },
  unitPrice: {
    type: Number,
    required: [true, 'Unit price is required'],
    min: [0, 'Unit price cannot be negative'],
  },
  subtotal: {
    type: Number,
    required: true,
    min: [0, 'Subtotal cannot be negative'],
  },
});

const saleSchema = new mongoose.Schema(
  {
    saleNumber: {
      type: String,
      required: true,
      unique: true,
    },
    document: {
      type: {
        type: String,
        enum: ['boleta', 'factura', 'ticket'],
        default: 'boleta',
      },
      code: {
        type: String,
        trim: true,
      },
      issuedAt: {
        type: Date,
      },
    },
    store: {
      name: {
        type: String,
        trim: true,
      },
      ruc: {
        type: String,
        trim: true,
      },
      address: {
        type: String,
        trim: true,
      },
      activity: {
        type: String,
        trim: true,
      },
      terminal: {
        type: String,
        trim: true,
      },
    },
    employee: {
      name: {
        type: String,
        trim: true,
      },
      role: {
        type: String,
        trim: true,
      },
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer',
      default: null,
    },
    client: {
      name: {
        type: String,
        trim: true,
      },
      location: {
        type: String,
        trim: true,
      },
      type: {
        type: String,
        enum: ['consumidor_final', 'empresa'],
        default: 'consumidor_final',
      },
    },
    items: [saleItemSchema],
    subtotal: {
      type: Number,
      required: true,
      min: [0, 'Subtotal cannot be negative'],
    },
    tax: {
      type: Number,
      default: 0,
      min: [0, 'Tax cannot be negative'],
    },
    discount: {
      type: Number,
      default: 0,
      min: [0, 'Discount cannot be negative'],
    },
    total: {
      type: Number,
      required: true,
      min: [0, 'Total cannot be negative'],
    },
    paymentMethod: {
      type: String,
      enum: ['cash', 'card', 'transfer', 'efectivo', 'tarjeta', 'transferencia'],
      default: 'cash',
    },
    paymentCurrency: {
      type: String,
      default: 'PEN',
    },
    paidAmount: {
      type: Number,
      min: [0, 'Paid amount cannot be negative'],
    },
    change: {
      type: Number,
      default: 0,
      min: [0, 'Change cannot be negative'],
    },
    status: {
      type: String,
      enum: ['completed', 'cancelled', 'completado', 'cancelado'],
      default: 'completed',
    },
    notes: {
      type: String,
      trim: true,
      maxlength: [500, 'Notes cannot exceed 500 characters'],
    },
    metadata: {
      createdBy: {
        type: String,
        default: 'system',
      },
      receiptImage: {
        type: String,
        trim: true,
      },
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Sale', saleSchema);
