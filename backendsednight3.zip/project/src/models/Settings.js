const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema(
  {
    storeName: {
      type: String,
      default: 'Sednight Minimarket',
    },
    storeEmail: {
      type: String,
      lowercase: true,
    },
    storePhone: {
      type: String,
    },
    storeAddress: {
      type: String,
    },
    taxRate: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },
    currency: {
      type: String,
      default: 'USD',
    },
    lowStockThreshold: {
      type: Number,
      default: 10,
      min: 0,
    },
    invoicePrefix: {
      type: String,
      default: 'INV',
    },
    purchasePrefix: {
      type: String,
      default: 'PUR',
    },
    defaultPaymentMethod: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PaymentMethod',
    },
    businessHours: {
      monday: {
        open: { type: String, default: '08:00' },
        close: { type: String, default: '20:00' },
      },
      tuesday: {
        open: { type: String, default: '08:00' },
        close: { type: String, default: '20:00' },
      },
      wednesday: {
        open: { type: String, default: '08:00' },
        close: { type: String, default: '20:00' },
      },
      thursday: {
        open: { type: String, default: '08:00' },
        close: { type: String, default: '20:00' },
      },
      friday: {
        open: { type: String, default: '08:00' },
        close: { type: String, default: '20:00' },
      },
      saturday: {
        open: { type: String, default: '09:00' },
        close: { type: String, default: '18:00' },
      },
      sunday: {
        open: { type: String, default: '10:00' },
        close: { type: String, default: '17:00' },
      },
    },
    allowCreditSales: {
      type: Boolean,
      default: false,
    },
    maxCreditDays: {
      type: Number,
      default: 30,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Settings', settingsSchema);
