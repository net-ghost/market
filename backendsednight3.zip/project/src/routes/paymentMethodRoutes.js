const express = require('express');
const router = express.Router();
const paymentMethodController = require('../controllers/paymentMethodController');
const { validatePaymentMethod, validatePaymentMethodUpdate } = require('../validators/paymentMethodValidator');
const { handleValidationErrors } = require('../middlewares/validationMiddleware');

router.get('/', paymentMethodController.getPaymentMethods);
router.get('/:id', paymentMethodController.getPaymentMethodById);
router.post('/', validatePaymentMethod, handleValidationErrors, paymentMethodController.createPaymentMethod);
router.put('/:id', validatePaymentMethodUpdate, handleValidationErrors, paymentMethodController.updatePaymentMethod);
router.delete('/:id', paymentMethodController.deletePaymentMethod);

module.exports = router;
