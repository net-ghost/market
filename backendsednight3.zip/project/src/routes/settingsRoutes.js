const express = require('express');
const router = express.Router();
const settingsController = require('../controllers/settingsController');
const { validateSettings } = require('../validators/settingsValidator');
const { handleValidationErrors } = require('../middlewares/validationMiddleware');

router.get('/', settingsController.getSettings);
router.put('/', validateSettings, handleValidationErrors, settingsController.updateSettings);

module.exports = router;
