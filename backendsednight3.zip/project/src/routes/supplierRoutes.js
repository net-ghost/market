const express = require('express');
const router = express.Router();
const supplierController = require('../controllers/supplierController');
const { validateSupplier, validateSupplierUpdate } = require('../validators/supplierValidator');
const { handleValidationErrors } = require('../middlewares/validationMiddleware');

router.get('/', supplierController.getSuppliers);
router.get('/:id', supplierController.getSupplierById);
router.post('/', validateSupplier, handleValidationErrors, supplierController.createSupplier);
router.put('/:id', validateSupplierUpdate, handleValidationErrors, supplierController.updateSupplier);
router.delete('/:id', supplierController.deleteSupplier);

module.exports = router;
