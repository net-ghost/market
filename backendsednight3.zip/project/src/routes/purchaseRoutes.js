const express = require('express');
const router = express.Router();
const purchaseController = require('../controllers/purchaseController');
const { validatePurchase, validatePurchaseUpdate } = require('../validators/purchaseValidator');
const { handleValidationErrors } = require('../middlewares/validationMiddleware');

router.get('/', purchaseController.getPurchases);
router.get('/:id', purchaseController.getPurchaseById);
router.post('/', validatePurchase, handleValidationErrors, purchaseController.createPurchase);
router.put('/:id', validatePurchaseUpdate, handleValidationErrors, purchaseController.updatePurchase);
router.delete('/:id', purchaseController.deletePurchase);

module.exports = router;
