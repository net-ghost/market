const { validationResult } = require('express-validator');
const { errorResponse } = require('../utils/responseHandler');

const validate = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map((error) => ({
      field: error.path,
      message: error.msg,
    }));

    return errorResponse(res, 400, 'Validation error', errorMessages);
  }

  next();
};

const handleValidationErrors = validate;

module.exports = validate;
module.exports.handleValidationErrors = handleValidationErrors;
