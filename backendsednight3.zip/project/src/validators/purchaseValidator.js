const { body } = require('express-validator');

const validatePurchase = [
  body('purchaseNumber')
    .notEmpty()
    .withMessage('Purchase number is required')
    .trim(),
  body('supplier')
    .notEmpty()
    .withMessage('Supplier is required')
    .isMongoId()
    .withMessage('Invalid supplier ID'),
  body('items')
    .isArray({ min: 1 })
    .withMessage('At least one item is required'),
  body('items.*.product')
    .notEmpty()
    .withMessage('Product is required')
    .isMongoId()
    .withMessage('Invalid product ID'),
  body('items.*.quantity')
    .notEmpty()
    .withMessage('Quantity is required')
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1'),
  body('items.*.unitPrice')
    .notEmpty()
    .withMessage('Unit price is required')
    .isFloat({ min: 0 })
    .withMessage('Unit price must be a positive number'),
  body('subtotal')
    .notEmpty()
    .withMessage('Subtotal is required')
    .isFloat({ min: 0 })
    .withMessage('Subtotal must be a positive number'),
  body('tax')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Tax must be a positive number'),
  body('discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Discount must be a positive number'),
  body('total')
    .notEmpty()
    .withMessage('Total is required')
    .isFloat({ min: 0 })
    .withMessage('Total must be a positive number'),
  body('status')
    .optional()
    .isIn(['Pending', 'Received', 'Partial', 'Cancelled'])
    .withMessage('Invalid status'),
  body('paymentMethod')
    .optional()
    .isMongoId()
    .withMessage('Invalid payment method ID'),
  body('paymentStatus')
    .optional()
    .isIn(['Pending', 'Partial', 'Paid', 'Overdue'])
    .withMessage('Invalid payment status'),
  body('deliveryDate').optional().isISO8601().withMessage('Invalid delivery date'),
  body('notes').optional().trim(),
];

const validatePurchaseUpdate = [
  body('purchaseNumber')
    .optional()
    .notEmpty()
    .withMessage('Purchase number cannot be empty')
    .trim(),
  body('supplier')
    .optional()
    .isMongoId()
    .withMessage('Invalid supplier ID'),
  body('items')
    .optional()
    .isArray({ min: 1 })
    .withMessage('At least one item is required'),
  body('items.*.product')
    .optional()
    .isMongoId()
    .withMessage('Invalid product ID'),
  body('items.*.quantity')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1'),
  body('items.*.unitPrice')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Unit price must be a positive number'),
  body('subtotal')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Subtotal must be a positive number'),
  body('tax')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Tax must be a positive number'),
  body('discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Discount must be a positive number'),
  body('total')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Total must be a positive number'),
  body('status')
    .optional()
    .isIn(['Pending', 'Received', 'Partial', 'Cancelled'])
    .withMessage('Invalid status'),
  body('paymentMethod')
    .optional()
    .isMongoId()
    .withMessage('Invalid payment method ID'),
  body('paymentStatus')
    .optional()
    .isIn(['Pending', 'Partial', 'Paid', 'Overdue'])
    .withMessage('Invalid payment status'),
  body('deliveryDate').optional().isISO8601().withMessage('Invalid delivery date'),
  body('notes').optional().trim(),
];

module.exports = {
  validatePurchase,
  validatePurchaseUpdate,
};
