const { body } = require('express-validator');

const validateSettings = [
  body('storeName').optional().notEmpty().withMessage('Store name cannot be empty').trim(),
  body('storeEmail').optional().isEmail().withMessage('Invalid email format'),
  body('storePhone').optional().trim(),
  body('storeAddress').optional().trim(),
  body('taxRate')
    .optional()
    .isFloat({ min: 0, max: 100 })
    .withMessage('Tax rate must be between 0 and 100'),
  body('currency').optional().trim(),
  body('lowStockThreshold')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Low stock threshold must be a positive number'),
  body('invoicePrefix').optional().trim(),
  body('purchasePrefix').optional().trim(),
  body('defaultPaymentMethod')
    .optional()
    .isMongoId()
    .withMessage('Invalid payment method ID'),
  body('businessHours').optional().isObject().withMessage('Business hours must be an object'),
  body('businessHours.*.open').optional().matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Invalid time format (HH:MM)'),
  body('businessHours.*.close').optional().matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Invalid time format (HH:MM)'),
  body('allowCreditSales').optional().isBoolean().withMessage('allowCreditSales must be a boolean'),
  body('maxCreditDays')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Max credit days must be at least 1'),
];

module.exports = {
  validateSettings,
};
