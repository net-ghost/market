const { body, validationResult } = require('express-validator');

const validatePaymentMethod = [
  body('name')
    .notEmpty()
    .withMessage('Payment method name is required')
    .isIn(['Cash', 'Debit Card', 'Credit Card', 'Check', 'Transfer', 'Mobile Payment'])
    .withMessage('Invalid payment method name'),
  body('description').optional().trim(),
  body('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  body('processingFee')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Processing fee must be a positive number'),
];

const validatePaymentMethodUpdate = [
  body('name')
    .optional()
    .isIn(['Cash', 'Debit Card', 'Credit Card', 'Check', 'Transfer', 'Mobile Payment'])
    .withMessage('Invalid payment method name'),
  body('description').optional().trim(),
  body('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  body('processingFee')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Processing fee must be a positive number'),
];

module.exports = {
  validatePaymentMethod,
  validatePaymentMethodUpdate,
};
