const { body } = require('express-validator');

const validateSupplier = [
  body('name').notEmpty().withMessage('Supplier name is required').trim(),
  body('contactPerson').optional().trim(),
  body('email').optional().isEmail().withMessage('Invalid email format'),
  body('phone').optional().trim(),
  body('address').optional().trim(),
  body('city').optional().trim(),
  body('state').optional().trim(),
  body('zipCode').optional().trim(),
  body('taxId').optional().trim(),
  body('bankAccount').optional().trim(),
  body('paymentTerms').optional().trim(),
  body('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  body('categories').optional().isArray().withMessage('Categories must be an array'),
];

const validateSupplierUpdate = [
  body('name').optional().notEmpty().withMessage('Supplier name cannot be empty').trim(),
  body('contactPerson').optional().trim(),
  body('email').optional().isEmail().withMessage('Invalid email format'),
  body('phone').optional().trim(),
  body('address').optional().trim(),
  body('city').optional().trim(),
  body('state').optional().trim(),
  body('zipCode').optional().trim(),
  body('taxId').optional().trim(),
  body('bankAccount').optional().trim(),
  body('paymentTerms').optional().trim(),
  body('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  body('categories').optional().isArray().withMessage('Categories must be an array'),
];

module.exports = {
  validateSupplier,
  validateSupplierUpdate,
};
