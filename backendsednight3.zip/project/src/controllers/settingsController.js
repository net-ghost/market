const { validationResult } = require('express-validator');
const Settings = require('../models/Settings');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const getSettings = async (req, res, next) => {
  try {
    let settings = await Settings.findOne().populate('defaultPaymentMethod', 'name');

    if (!settings) {
      settings = new Settings();
      await settings.save();
      settings = await settings.populate('defaultPaymentMethod', 'name');
    }

    return successResponse(res, 200, 'Settings retrieved successfully', settings);
  } catch (error) {
    next(error);
  }
};

const updateSettings = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    let settings = await Settings.findOne();

    if (!settings) {
      settings = new Settings(req.body);
    } else {
      Object.assign(settings, req.body);
    }

    await settings.save();
    settings = await settings.populate('defaultPaymentMethod', 'name');

    return successResponse(res, 200, 'Settings updated successfully', settings);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getSettings,
  updateSettings,
};
