const { validationResult } = require('express-validator');
const PaymentMethod = require('../models/PaymentMethod');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const getPaymentMethods = async (req, res, next) => {
  try {
    const paymentMethods = await PaymentMethod.find().sort({ createdAt: -1 });
    return successResponse(res, 200, 'Payment methods retrieved successfully', paymentMethods);
  } catch (error) {
    next(error);
  }
};

const getPaymentMethodById = async (req, res, next) => {
  try {
    const paymentMethod = await PaymentMethod.findById(req.params.id);
    if (!paymentMethod) {
      return errorResponse(res, 404, 'Payment method not found');
    }
    return successResponse(res, 200, 'Payment method retrieved successfully', paymentMethod);
  } catch (error) {
    next(error);
  }
};

const createPaymentMethod = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const paymentMethod = new PaymentMethod(req.body);
    await paymentMethod.save();
    return successResponse(res, 201, 'Payment method created successfully', paymentMethod);
  } catch (error) {
    next(error);
  }
};

const updatePaymentMethod = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const paymentMethod = await PaymentMethod.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!paymentMethod) {
      return errorResponse(res, 404, 'Payment method not found');
    }

    return successResponse(res, 200, 'Payment method updated successfully', paymentMethod);
  } catch (error) {
    next(error);
  }
};

const deletePaymentMethod = async (req, res, next) => {
  try {
    const paymentMethod = await PaymentMethod.findByIdAndDelete(req.params.id);
    if (!paymentMethod) {
      return errorResponse(res, 404, 'Payment method not found');
    }
    return successResponse(res, 200, 'Payment method deleted successfully');
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getPaymentMethods,
  getPaymentMethodById,
  createPaymentMethod,
  updatePaymentMethod,
  deletePaymentMethod,
};
