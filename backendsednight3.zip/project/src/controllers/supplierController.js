const { validationResult } = require('express-validator');
const Supplier = require('../models/Supplier');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const getSuppliers = async (req, res, next) => {
  try {
    const { isActive } = req.query;
    const filter = isActive !== undefined ? { isActive: isActive === 'true' } : {};

    const suppliers = await Supplier.find(filter).sort({ createdAt: -1 });
    return successResponse(res, 200, 'Suppliers retrieved successfully', suppliers);
  } catch (error) {
    next(error);
  }
};

const getSupplierById = async (req, res, next) => {
  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier) {
      return errorResponse(res, 404, 'Supplier not found');
    }
    return successResponse(res, 200, 'Supplier retrieved successfully', supplier);
  } catch (error) {
    next(error);
  }
};

const createSupplier = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const supplier = new Supplier(req.body);
    await supplier.save();
    return successResponse(res, 201, 'Supplier created successfully', supplier);
  } catch (error) {
    next(error);
  }
};

const updateSupplier = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const supplier = await Supplier.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!supplier) {
      return errorResponse(res, 404, 'Supplier not found');
    }

    return successResponse(res, 200, 'Supplier updated successfully', supplier);
  } catch (error) {
    next(error);
  }
};

const deleteSupplier = async (req, res, next) => {
  try {
    const supplier = await Supplier.findByIdAndDelete(req.params.id);
    if (!supplier) {
      return errorResponse(res, 404, 'Supplier not found');
    }
    return successResponse(res, 200, 'Supplier deleted successfully');
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getSuppliers,
  getSupplierById,
  createSupplier,
  updateSupplier,
  deleteSupplier,
};
