const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // Passing useNewUrlParser/useUnifiedTopology is deprecated for the
    // Node MongoDB driver v4+ and has no effect. Let mongoose use its
    // defaults. If you need to customize behavior, prefer explicit
    // options such as serverSelectionTimeoutMS or maxPoolSize.
    const conn = await mongoose.connect(process.env.MONGODB_URI);

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
