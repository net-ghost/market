const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { errorHandler, notFound } = require('./middlewares/errorMiddleware');

const apiRoutes = require('./routes');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Welcome to Sednight API - Minimarket Management System',
    version: '1.0.0',
    endpoints: {
      categories: '/market/api/categories',
      products: '/market/api/products',
      customers: '/market/api/customers',
      sales: '/market/api/sales',
      paymentMethods: '/market/api/payment-methods',
      suppliers: '/market/api/suppliers',
      purchases: '/market/api/purchases',
      settings: '/market/api/settings',
    },
  });
});

app.use('/market/api', apiRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
