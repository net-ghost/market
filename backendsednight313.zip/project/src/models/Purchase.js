const mongoose = require('mongoose');

const purchaseSchema = new mongoose.Schema(
  {
    purchaseNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    supplier: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Supplier',
      required: true,
    },
    items: [
      {
        product: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Product',
          required: true,
        },
        productName: {
          type: String,
          trim: true,
        },
        productCode: {
          type: String,
          trim: true,
        },
        quantity: {
          type: Number,
          required: true,
          min: 0.001,
        },
        unit: {
          type: String,
          enum: ['unit', 'kg', 'gram', 'liter', 'ml', 'pack', 'box', 'dozen', 'meter', 'cm'],
          default: 'unit',
        },
        unitPrice: {
          type: Number,
          required: true,
          min: 0,
        },
        discount: {
          type: Number,
          default: 0,
          min: 0,
        },
        tax: {
          type: Number,
          default: 0,
          min: 0,
        },
        total: {
          type: Number,
          required: true,
          min: 0,
        },
      },
    ],
    subtotal: {
      type: Number,
      required: true,
      min: 0,
    },
    tax: {
      type: Number,
      default: 0,
      min: 0,
    },
    discount: {
      type: Number,
      default: 0,
      min: 0,
    },
    total: {
      type: Number,
      required: true,
      min: 0,
    },
    status: {
      type: String,
      enum: ['Pending', 'Received', 'Partial', 'Cancelled'],
      default: 'Pending',
    },
    payments: [
      {
        method: {
          type: String,
          enum: ['cash', 'card', 'transfer', 'efectivo', 'tarjeta', 'transferencia', 'credit', 'credito', 'check', 'cheque'],
          required: true,
        },
        amount: {
          type: Number,
          required: true,
          min: [0, 'Payment amount cannot be negative'],
        },
        currency: {
          type: String,
          default: 'PEN',
        },
        reference: {
          type: String,
          trim: true,
        },
        dueDate: {
          type: Date,
        },
        paidDate: {
          type: Date,
        },
        status: {
          type: String,
          enum: ['Pending', 'Paid', 'Overdue'],
          default: 'Pending',
        },
        notes: {
          type: String,
          trim: true,
        },
      },
    ],
    paymentMethod: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PaymentMethod',
    },
    paymentStatus: {
      type: String,
      enum: ['Pending', 'Partial', 'Paid', 'Overdue'],
      default: 'Pending',
    },
    deliveryDate: {
      type: Date,
    },
    notes: {
      type: String,
      trim: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Purchase', purchaseSchema);
