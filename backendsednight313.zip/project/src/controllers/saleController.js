const Sale = require('../models/Sale');
const Product = require('../models/Product');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const generateSaleNumber = async () => {
  const lastSale = await Sale.findOne().sort({ createdAt: -1 });
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0');

  let sequence = 1;

  if (lastSale && lastSale.saleNumber) {
    const lastNumber = lastSale.saleNumber.split('-')[2];
    sequence = parseInt(lastNumber) + 1;
  }

  return `S-${year}${month}-${String(sequence).padStart(6, '0')}`;
};

const getAllSales = async (req, res, next) => {
  try {
    const { status, startDate, endDate, customer } = req.query;
    const filter = {};

    if (status) {
      filter.status = status;
    }

    if (customer) {
      filter.customer = customer;
    }

    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) {
        filter.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        filter.createdAt.$lte = new Date(endDate);
      }
    }

    const sales = await Sale.find(filter)
      .populate('customer', 'name documentNumber')
      .populate('items.product', 'name')
      .sort({ createdAt: -1 });

    successResponse(res, 200, 'Sales retrieved successfully', sales);
  } catch (error) {
    next(error);
  }
};

const getSaleById = async (req, res, next) => {
  try {
    const sale = await Sale.findById(req.params.id)
      .populate('customer', 'name email phone documentType documentNumber')
      .populate('items.product', 'name barcode');

    if (!sale) {
      return errorResponse(res, 404, 'Sale not found');
    }

    successResponse(res, 200, 'Sale retrieved successfully', sale);
  } catch (error) {
    next(error);
  }
};

const createSale = async (req, res, next) => {
  try {
    const {
      items,
      discount = 0,
      paymentMethod,
      customer,
      notes,
      document,
      store,
      employee,
      client,
      payment,
      metadata
    } = req.body;

    let subtotal = 0;
    const saleItems = [];

    for (const item of items) {
      let product;

      if (item.product) {
        product = await Product.findById(item.product);
      } else if (item.productCode) {
        product = await Product.findOne({ barcode: item.productCode });
      }

      if (!product) {
        return errorResponse(
          res,
          404,
          `Product with ID ${item.product || item.productCode} not found`
        );
      }

      if (!product.isActive) {
        return errorResponse(res, 400, `Product ${product.name} is not active`);
      }

      if (product.stock < item.quantity) {
        return errorResponse(
          res,
          400,
          `Insufficient stock for product: ${product.name}. Available: ${product.stock}`
        );
      }

      const itemUnitPrice = item.unitPrice || product.price;
      const itemDiscount = item.discount || 0;
      const itemTax = item.tax || 0;
      const itemSubtotal = item.subtotal || ((itemUnitPrice * item.quantity) - itemDiscount + itemTax);
      subtotal += itemSubtotal;

      saleItems.push({
        product: product._id,
        productCode: item.productCode || product.barcode,
        productName: item.name || product.name,
        quantity: item.quantity,
        unit: item.unit || product.unit,
        unitPrice: itemUnitPrice,
        discount: itemDiscount,
        tax: itemTax,
        subtotal: itemSubtotal,
      });

      product.stock -= item.quantity;
      await product.save();
    }

    const calculatedSubtotal = payment?.subtotal || subtotal;
    const tax = payment?.tax !== undefined ? payment.tax : (calculatedSubtotal * 0.18);
    const finalDiscount = payment?.discount !== undefined ? payment.discount : discount;
    const total = payment?.total || (calculatedSubtotal + tax - finalDiscount);

    const saleNumber = document?.code || await generateSaleNumber();

    const normalizedPaymentMethod = paymentMethod || payment?.method || 'cash';
    const methodMap = {
      'efectivo': 'cash',
      'tarjeta': 'card',
      'transferencia': 'transfer'
    };
    const finalPaymentMethod = methodMap[normalizedPaymentMethod] || normalizedPaymentMethod;

    const normalizedStatus = req.body.status || payment?.status || 'completed';
    const statusMap = {
      'completado': 'completed',
      'cancelado': 'cancelled'
    };
    const finalStatus = statusMap[normalizedStatus] || normalizedStatus;

    const saleData = {
      saleNumber,
      customer: customer || null,
      items: saleItems,
      subtotal: calculatedSubtotal,
      tax,
      discount: finalDiscount,
      total,
      paymentMethod: finalPaymentMethod,
      status: finalStatus,
      notes,
    };

    if (req.body.payments && req.body.payments.length > 0) {
      saleData.payments = req.body.payments.map(p => ({
        method: p.method,
        amount: p.amount,
        currency: p.currency || 'PEN',
        reference: p.reference,
        notes: p.notes,
      }));
    }

    if (document) {
      saleData.document = {
        type: document.type,
        code: document.code,
        issuedAt: document.issuedAt ? new Date(document.issuedAt) : new Date(),
      };
    }

    if (store) {
      saleData.store = store;
    }

    if (employee) {
      saleData.employee = employee;
    }

    if (client) {
      saleData.client = client;
    }

    if (payment) {
      saleData.paymentCurrency = payment.currency || 'PEN';
      saleData.paidAmount = payment.paidAmount || total;
      saleData.change = payment.change || 0;

      if (!saleData.payments || saleData.payments.length === 0) {
        saleData.payments = [{
          method: payment.method || finalPaymentMethod,
          amount: payment.paidAmount || total,
          currency: payment.currency || 'PEN',
          reference: payment.reference,
          notes: payment.notes,
        }];
      }
    }

    if (metadata) {
      saleData.metadata = {
        createdBy: metadata.createdBy || 'system',
        receiptImage: metadata.receiptImage,
      };
    }

    const sale = await Sale.create(saleData);

    const populatedSale = await Sale.findById(sale._id)
      .populate('customer', 'name documentNumber')
      .populate('items.product', 'name');

    successResponse(res, 201, 'Sale created successfully', populatedSale);
  } catch (error) {
    next(error);
  }
};

const updateSaleStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const sale = await Sale.findById(req.params.id);

    if (!sale) {
      return errorResponse(res, 404, 'Sale not found');
    }

    if (status === 'cancelled' && sale.status !== 'cancelled') {
      for (const item of sale.items) {
        const product = await Product.findById(item.product);
        if (product) {
          product.stock += item.quantity;
          await product.save();
        }
      }
    }

    sale.status = status;
    await sale.save();

    successResponse(res, 200, 'Sale status updated successfully', sale);
  } catch (error) {
    next(error);
  }
};

const getSalesStats = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;
    const matchFilter = { status: 'completed' };

    if (startDate || endDate) {
      matchFilter.createdAt = {};
      if (startDate) {
        matchFilter.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        matchFilter.createdAt.$lte = new Date(endDate);
      }
    }

    const stats = await Sale.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: null,
          totalSales: { $sum: 1 },
          totalRevenue: { $sum: '$total' },
          totalTax: { $sum: '$tax' },
          totalDiscount: { $sum: '$discount' },
          averageSale: { $avg: '$total' },
        },
      },
    ]);

    const result = stats.length > 0 ? stats[0] : {
      totalSales: 0,
      totalRevenue: 0,
      totalTax: 0,
      totalDiscount: 0,
      averageSale: 0,
    };

    delete result._id;

    successResponse(res, 200, 'Sales statistics retrieved successfully', result);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllSales,
  getSaleById,
  createSale,
  updateSaleStatus,
  getSalesStats,
};
