const { validationResult } = require('express-validator');
const Purchase = require('../models/Purchase');
const Product = require('../models/Product');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const getPurchases = async (req, res, next) => {
  try {
    const { status, paymentStatus } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (paymentStatus) filter.paymentStatus = paymentStatus;

    const purchases = await Purchase.find(filter)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name sku')
      .populate('paymentMethod', 'name')
      .sort({ createdAt: -1 });

    return successResponse(res, 200, 'Purchases retrieved successfully', purchases);
  } catch (error) {
    next(error);
  }
};

const getPurchaseById = async (req, res, next) => {
  try {
    const purchase = await Purchase.findById(req.params.id)
      .populate('supplier')
      .populate('items.product')
      .populate('paymentMethod');

    if (!purchase) {
      return errorResponse(res, 404, 'Purchase not found');
    }

    return successResponse(res, 200, 'Purchase retrieved successfully', purchase);
  } catch (error) {
    next(error);
  }
};

const createPurchase = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const { items } = req.body;

    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) {
        return errorResponse(res, 404, `Product with ID ${item.product} not found`);
      }

      item.productName = item.productName || product.name;
      item.productCode = item.productCode || product.barcode;
      item.unit = item.unit || product.unit;

      const itemDiscount = item.discount || 0;
      const itemTax = item.tax || 0;
      item.total = (item.quantity * item.unitPrice) - itemDiscount + itemTax;
    }

    const purchaseData = { ...req.body };

    if (req.body.payments && req.body.payments.length > 0) {
      purchaseData.payments = req.body.payments.map(p => ({
        method: p.method,
        amount: p.amount,
        currency: p.currency || 'PEN',
        reference: p.reference,
        dueDate: p.dueDate,
        paidDate: p.paidDate,
        status: p.status || 'Pending',
        notes: p.notes,
      }));
    }

    const purchase = new Purchase(purchaseData);
    await purchase.save();

    const populatedPurchase = await purchase.populate('supplier').populate('items.product').populate('paymentMethod');

    return successResponse(res, 201, 'Purchase created successfully', populatedPurchase);
  } catch (error) {
    next(error);
  }
};

const updatePurchase = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 400, 'Validation error', errors.array());
    }

    const purchase = await Purchase.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    )
      .populate('supplier')
      .populate('items.product')
      .populate('paymentMethod');

    if (!purchase) {
      return errorResponse(res, 404, 'Purchase not found');
    }

    return successResponse(res, 200, 'Purchase updated successfully', purchase);
  } catch (error) {
    next(error);
  }
};

const deletePurchase = async (req, res, next) => {
  try {
    const purchase = await Purchase.findByIdAndDelete(req.params.id);
    if (!purchase) {
      return errorResponse(res, 404, 'Purchase not found');
    }
    return successResponse(res, 200, 'Purchase deleted successfully');
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getPurchases,
  getPurchaseById,
  createPurchase,
  updatePurchase,
  deletePurchase,
};
