const { body, param } = require('express-validator');

const createSaleValidator = [
  body('customer')
    .optional()
    .isMongoId()
    .withMessage('Invalid customer ID'),
  body('items')
    .isArray({ min: 1 })
    .withMessage('Sale must contain at least one item'),
  body('items.*.product')
    .optional()
    .isMongoId()
    .withMessage('Invalid product ID'),
  body('items.*.productCode')
    .optional()
    .trim(),
  body('items.*.name')
    .optional()
    .trim(),
  body('items.*.quantity')
    .notEmpty()
    .withMessage('Quantity is required')
    .isFloat({ min: 0.001 })
    .withMessage('Quantity must be greater than 0'),
  body('items.*.unit')
    .optional()
    .isIn(['unit', 'kg', 'gram', 'liter', 'ml', 'pack', 'box', 'dozen', 'meter', 'cm'])
    .withMessage('Unit must be one of: unit, kg, gram, liter, ml, pack, box, dozen, meter, cm'),
  body('items.*.unitPrice')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Unit price must be a non-negative number'),
  body('items.*.discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Discount must be a non-negative number'),
  body('items.*.tax')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Tax must be a non-negative number'),
  body('items.*.subtotal')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Subtotal must be a non-negative number'),
  body('payments')
    .optional()
    .isArray()
    .withMessage('Payments must be an array'),
  body('payments.*.method')
    .optional()
    .isIn(['cash', 'card', 'transfer', 'efectivo', 'tarjeta', 'transferencia', 'credit', 'credito', 'mobile', 'movil'])
    .withMessage('Invalid payment method'),
  body('payments.*.amount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Payment amount must be a non-negative number'),
  body('payments.*.currency')
    .optional()
    .trim(),
  body('payments.*.reference')
    .optional()
    .trim(),
  body('payments.*.notes')
    .optional()
    .trim(),
  body('paymentMethod')
    .optional()
    .isIn(['cash', 'card', 'transfer', 'efectivo', 'tarjeta', 'transferencia'])
    .withMessage('Invalid payment method'),
  body('discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Discount must be a non-negative number'),
  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),
  body('document')
    .optional()
    .isObject()
    .withMessage('Document must be an object'),
  body('document.type')
    .optional()
    .isIn(['boleta', 'factura', 'ticket'])
    .withMessage('Document type must be one of: boleta, factura, ticket'),
  body('document.code')
    .optional()
    .trim(),
  body('document.issuedAt')
    .optional()
    .isISO8601()
    .withMessage('Invalid date format'),
  body('store')
    .optional()
    .isObject()
    .withMessage('Store must be an object'),
  body('employee')
    .optional()
    .isObject()
    .withMessage('Employee must be an object'),
  body('client')
    .optional()
    .isObject()
    .withMessage('Client must be an object'),
  body('client.type')
    .optional()
    .isIn(['consumidor_final', 'empresa'])
    .withMessage('Client type must be one of: consumidor_final, empresa'),
  body('payment')
    .optional()
    .isObject()
    .withMessage('Payment must be an object'),
  body('payment.method')
    .optional()
    .isIn(['cash', 'card', 'transfer', 'efectivo', 'tarjeta', 'transferencia', 'credit', 'credito', 'mobile', 'movil'])
    .withMessage('Invalid payment method'),
  body('payment.currency')
    .optional()
    .trim(),
  body('payment.subtotal')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Payment subtotal must be a non-negative number'),
  body('payment.discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Payment discount must be a non-negative number'),
  body('payment.tax')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Payment tax must be a non-negative number'),
  body('payment.total')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Payment total must be a non-negative number'),
  body('payment.paidAmount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Paid amount must be a non-negative number'),
  body('payment.change')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Change must be a non-negative number'),
  body('status')
    .optional()
    .isIn(['completed', 'cancelled', 'completado', 'cancelado'])
    .withMessage('Invalid status'),
  body('metadata')
    .optional()
    .isObject()
    .withMessage('Metadata must be an object'),
  body('metadata.createdBy')
    .optional()
    .trim(),
  body('metadata.receiptImage')
    .optional()
    .trim(),
];

const updateSaleStatusValidator = [
  param('id').isMongoId().withMessage('Invalid sale ID'),
  body('status')
    .notEmpty()
    .withMessage('Status is required')
    .isIn(['completed', 'cancelled', 'completado', 'cancelado'])
    .withMessage('Status must be one of: completed, cancelled, completado, cancelado'),
];

const saleIdValidator = [
  param('id').isMongoId().withMessage('Invalid sale ID'),
];

module.exports = {
  createSaleValidator,
  updateSaleStatusValidator,
  saleIdValidator,
};
