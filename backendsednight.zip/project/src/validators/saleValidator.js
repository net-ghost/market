const { body, param } = require('express-validator');

const createSaleValidator = [
  body('customer')
    .optional()
    .isMongoId()
    .withMessage('Invalid customer ID'),
  body('items')
    .isArray({ min: 1 })
    .withMessage('Sale must contain at least one item'),
  body('items.*.product')
    .notEmpty()
    .withMessage('Product ID is required')
    .isMongoId()
    .withMessage('Invalid product ID'),
  body('items.*.quantity')
    .notEmpty()
    .withMessage('Quantity is required')
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1'),
  body('paymentMethod')
    .optional()
    .isIn(['cash', 'card', 'transfer'])
    .withMessage('Payment method must be one of: cash, card, transfer'),
  body('discount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Discount must be a non-negative number'),
  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),
];

const updateSaleStatusValidator = [
  param('id').isMongoId().withMessage('Invalid sale ID'),
  body('status')
    .notEmpty()
    .withMessage('Status is required')
    .isIn(['completed', 'cancelled'])
    .withMessage('Status must be one of: completed, cancelled'),
];

const saleIdValidator = [
  param('id').isMongoId().withMessage('Invalid sale ID'),
];

module.exports = {
  createSaleValidator,
  updateSaleStatusValidator,
  saleIdValidator,
};
