const { body, param } = require('express-validator');

const createCustomerValidator = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Customer name is required')
    .isLength({ max: 100 })
    .withMessage('Customer name cannot exceed 100 characters'),
  body('email')
    .optional()
    .trim()
    .isEmail()
    .withMessage('Please enter a valid email')
    .normalizeEmail(),
  body('phone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Phone number cannot exceed 20 characters'),
  body('address')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Address cannot exceed 200 characters'),
  body('documentType')
    .optional()
    .isIn(['DNI', 'RUC', 'CE', 'Passport'])
    .withMessage('Document type must be one of: DNI, RUC, CE, Passport'),
  body('documentNumber').optional().trim(),
];

const updateCustomerValidator = [
  param('id').isMongoId().withMessage('Invalid customer ID'),
  body('name')
    .optional()
    .trim()
    .notEmpty()
    .withMessage('Customer name cannot be empty')
    .isLength({ max: 100 })
    .withMessage('Customer name cannot exceed 100 characters'),
  body('email')
    .optional()
    .trim()
    .isEmail()
    .withMessage('Please enter a valid email')
    .normalizeEmail(),
  body('phone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Phone number cannot exceed 20 characters'),
  body('address')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Address cannot exceed 200 characters'),
  body('documentType')
    .optional()
    .isIn(['DNI', 'RUC', 'CE', 'Passport'])
    .withMessage('Document type must be one of: DNI, RUC, CE, Passport'),
  body('documentNumber').optional().trim(),
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
];

const customerIdValidator = [
  param('id').isMongoId().withMessage('Invalid customer ID'),
];

module.exports = {
  createCustomerValidator,
  updateCustomerValidator,
  customerIdValidator,
};
