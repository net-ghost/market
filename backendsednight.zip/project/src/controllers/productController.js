const Product = require('../models/Product');
const { successResponse, errorResponse } = require('../utils/responseHandler');

const getAllProducts = async (req, res, next) => {
  try {
    const { isActive, category, search, lowStock } = req.query;
    const filter = {};

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (category) {
      filter.category = category;
    }

    if (search) {
      filter.$text = { $search: search };
    }

    const products = await Product.find(filter)
      .populate('category', 'name')
      .sort({ createdAt: -1 });

    let filteredProducts = products;

    if (lowStock === 'true') {
      filteredProducts = products.filter(
        (product) => product.stock <= product.minStock
      );
    }

    successResponse(res, 200, 'Products retrieved successfully', filteredProducts);
  } catch (error) {
    next(error);
  }
};

const getProductById = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate(
      'category',
      'name'
    );

    if (!product) {
      return errorResponse(res, 404, 'Product not found');
    }

    successResponse(res, 200, 'Product retrieved successfully', product);
  } catch (error) {
    next(error);
  }
};

const createProduct = async (req, res, next) => {
  try {
    const product = await Product.create(req.body);
    const populatedProduct = await Product.findById(product._id).populate(
      'category',
      'name'
    );

    successResponse(res, 201, 'Product created successfully', populatedProduct);
  } catch (error) {
    next(error);
  }
};

const updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate('category', 'name');

    if (!product) {
      return errorResponse(res, 404, 'Product not found');
    }

    successResponse(res, 200, 'Product updated successfully', product);
  } catch (error) {
    next(error);
  }
};

const deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);

    if (!product) {
      return errorResponse(res, 404, 'Product not found');
    }

    successResponse(res, 200, 'Product deleted successfully', product);
  } catch (error) {
    next(error);
  }
};

const updateStock = async (req, res, next) => {
  try {
    const { quantity, operation } = req.body;

    if (!quantity || !operation) {
      return errorResponse(
        res,
        400,
        'Quantity and operation (add/subtract) are required'
      );
    }

    const product = await Product.findById(req.params.id);

    if (!product) {
      return errorResponse(res, 404, 'Product not found');
    }

    if (operation === 'add') {
      product.stock += quantity;
    } else if (operation === 'subtract') {
      if (product.stock < quantity) {
        return errorResponse(res, 400, 'Insufficient stock');
      }
      product.stock -= quantity;
    } else {
      return errorResponse(res, 400, 'Invalid operation. Use "add" or "subtract"');
    }

    await product.save();

    successResponse(res, 200, 'Stock updated successfully', product);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  updateStock,
};
