const express = require('express');
const router = express.Router();
const {
  getAllSales,
  getSaleById,
  createSale,
  updateSaleStatus,
  getSalesStats,
} = require('../controllers/saleController');
const {
  createSaleValidator,
  updateSaleStatusValidator,
  saleIdValidator,
} = require('../validators/saleValidator');
const validate = require('../middlewares/validationMiddleware');

router
  .route('/')
  .get(getAllSales)
  .post(createSaleValidator, validate, createSale);

router.route('/stats').get(getSalesStats);

router
  .route('/:id')
  .get(saleIdValidator, validate, getSaleById);

router
  .route('/:id/status')
  .patch(updateSaleStatusValidator, validate, updateSaleStatus);

module.exports = router;
