const express = require('express');
const router = express.Router();
const {
  getAllCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory,
} = require('../controllers/categoryController');
const {
  createCategoryValidator,
  updateCategoryValidator,
  categoryIdValidator,
} = require('../validators/categoryValidator');
const validate = require('../middlewares/validationMiddleware');

router
  .route('/')
  .get(getAllCategories)
  .post(createCategoryValidator, validate, createCategory);

router
  .route('/:id')
  .get(categoryIdValidator, validate, getCategoryById)
  .put(updateCategoryValidator, validate, updateCategory)
  .delete(categoryIdValidator, validate, deleteCategory);

module.exports = router;
