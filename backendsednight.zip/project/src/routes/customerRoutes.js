const express = require('express');
const router = express.Router();
const {
  getAllCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
} = require('../controllers/customerController');
const {
  createCustomerValidator,
  updateCustomerValidator,
  customerIdValidator,
} = require('../validators/customerValidator');
const validate = require('../middlewares/validationMiddleware');

router
  .route('/')
  .get(getAllCustomers)
  .post(createCustomerValidator, validate, createCustomer);

router
  .route('/:id')
  .get(customerIdValidator, validate, getCustomerById)
  .put(updateCustomerValidator, validate, updateCustomer)
  .delete(customerIdValidator, validate, deleteCustomer);

module.exports = router;
