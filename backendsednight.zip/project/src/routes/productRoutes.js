const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  updateStock,
} = require('../controllers/productController');
const {
  createProductValidator,
  updateProductValidator,
  productIdValidator,
} = require('../validators/productValidator');
const validate = require('../middlewares/validationMiddleware');

router
  .route('/')
  .get(getAllProducts)
  .post(createProductValidator, validate, createProduct);

router
  .route('/:id')
  .get(productIdValidator, validate, getProductById)
  .put(updateProductValidator, validate, updateProduct)
  .delete(productIdValidator, validate, deleteProduct);

router
  .route('/:id/stock')
  .patch(productIdValidator, validate, updateStock);

module.exports = router;
