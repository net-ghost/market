# Sednight API - Sistema de Gestion para Minimarket

Backend API REST completo desarrollado con Node.js, Express y MongoDB para la gestion de un minimarket.

## Caracteristicas

- Gestion de productos con control de inventario
- Gestion de categorias de productos
- Gestion de clientes
- Sistema de ventas con generacion automatica de numeros de venta
- Validaciones completas en todos los endpoints
- Manejo centralizado de errores
- Estadisticas de ventas

## Tecnologias

- **Node.js** - Entorno de ejecucion
- **Express** - Framework web
- **MongoDB** - Base de datos
- **Mongoose** - ODM para MongoDB
- **Express Validator** - Validacion de datos
- **Morgan** - Logger HTTP
- **CORS** - Manejo de CORS
- **dotenv** - Variables de entorno

## Estructura del Proyecto

```
sednight/
├── src/
│   ├── config/
│   │   └── database.js          # Configuracion de MongoDB
│   ├── models/
│   │   ├── Category.js          # Modelo de categoria
│   │   ├── Product.js           # Modelo de producto
│   │   ├── Customer.js          # Modelo de cliente
│   │   └── Sale.js              # Modelo de venta
│   ├── controllers/
│   │   ├── categoryController.js
│   │   ├── productController.js
│   │   ├── customerController.js
│   │   └── saleController.js
│   ├── routes/
│   │   ├── categoryRoutes.js
│   │   ├── productRoutes.js
│   │   ├── customerRoutes.js
│   │   └── saleRoutes.js
│   ├── validators/
│   │   ├── categoryValidator.js
│   │   ├── productValidator.js
│   │   ├── customerValidator.js
│   │   └── saleValidator.js
│   ├── middlewares/
│   │   ├── errorMiddleware.js
│   │   └── validationMiddleware.js
│   ├── utils/
│   │   └── responseHandler.js
│   └── app.js
├── index.js
├── .env
└── package.json
```

## Instalacion

1. Instalar dependencias:
```bash
npm install
```

2. Configurar variables de entorno en `.env`:
```
PORT=3000
MONGODB_URI=mongodb://localhost:27017/sednight
```

3. Asegurate de tener MongoDB ejecutandose localmente o actualiza `MONGODB_URI` con tu conexion remota.

## Uso

Iniciar el servidor:
```bash
npm start
```

El servidor se ejecutara en `http://localhost:3000`

## Endpoints

### Categorias

- `GET /api/categories` - Obtener todas las categorias
  - Query params: `?isActive=true`
- `GET /api/categories/:id` - Obtener una categoria
- `POST /api/categories` - Crear categoria
- `PUT /api/categories/:id` - Actualizar categoria
- `DELETE /api/categories/:id` - Eliminar categoria

### Productos

- `GET /api/products` - Obtener todos los productos
  - Query params: `?isActive=true&category=ID&search=texto&lowStock=true`
- `GET /api/products/:id` - Obtener un producto
- `POST /api/products` - Crear producto
- `PUT /api/products/:id` - Actualizar producto
- `PATCH /api/products/:id/stock` - Actualizar stock
- `DELETE /api/products/:id` - Eliminar producto

### Clientes

- `GET /api/customers` - Obtener todos los clientes
  - Query params: `?isActive=true&search=texto`
- `GET /api/customers/:id` - Obtener un cliente
- `POST /api/customers` - Crear cliente
- `PUT /api/customers/:id` - Actualizar cliente
- `DELETE /api/customers/:id` - Eliminar cliente

### Ventas

- `GET /api/sales` - Obtener todas las ventas
  - Query params: `?status=completed&startDate=2024-01-01&endDate=2024-12-31&customer=ID`
- `GET /api/sales/stats` - Obtener estadisticas de ventas
  - Query params: `?startDate=2024-01-01&endDate=2024-12-31`
- `GET /api/sales/:id` - Obtener una venta
- `POST /api/sales` - Crear venta
- `PATCH /api/sales/:id/status` - Actualizar estado de venta

## Ejemplos de Uso

### Crear una categoria
```json
POST /api/categories
{
  "name": "Bebidas",
  "description": "Bebidas frias y calientes"
}
```

### Crear un producto
```json
POST /api/products
{
  "name": "Coca Cola 500ml",
  "description": "Bebida gaseosa",
  "price": 2.50,
  "cost": 1.50,
  "stock": 100,
  "category": "ID_DE_CATEGORIA",
  "barcode": "7501234567890",
  "unit": "unit",
  "minStock": 10
}
```

### Crear un cliente
```json
POST /api/customers
{
  "name": "Juan Perez",
  "email": "juan@example.com",
  "phone": "987654321",
  "address": "Av. Principal 123",
  "documentType": "DNI",
  "documentNumber": "12345678"
}
```

### Crear una venta
```json
POST /api/sales
{
  "customer": "ID_DEL_CLIENTE",
  "items": [
    {
      "product": "ID_DEL_PRODUCTO",
      "quantity": 2
    }
  ],
  "paymentMethod": "cash",
  "discount": 0,
  "notes": "Venta al contado"
}
```

### Actualizar stock de producto
```json
PATCH /api/products/:id/stock
{
  "quantity": 50,
  "operation": "add"
}
```

## Validaciones

Todos los endpoints tienen validaciones completas:

- Campos requeridos
- Formatos de datos (email, numeros, etc.)
- Longitudes maximas
- Valores permitidos (enums)
- IDs de MongoDB validos

## Manejo de Errores

El API incluye un sistema completo de manejo de errores:

- Validaciones de Mongoose
- Errores de Cast (IDs invalidos)
- Duplicados (codigo 11000)
- Errores personalizados
- Errores 404 para rutas no encontradas

Formato de respuesta de error:
```json
{
  "success": false,
  "message": "Error message",
  "errors": []
}
```

## Formato de Respuestas

Todas las respuestas exitosas siguen este formato:
```json
{
  "success": true,
  "message": "Operation message",
  "data": {}
}
```

## Caracteristicas del Sistema de Ventas

- Generacion automatica de numero de venta (formato: S-YYYYMM-000001)
- Calculo automatico de subtotal, impuesto (18%) y total
- Descuento opcional
- Actualizacion automatica de inventario al crear venta
- Reversion de inventario al cancelar venta
- Soporte para ventas sin cliente (ventas genericas)
- Estadisticas de ventas con filtros por fecha

## Base de Datos

La base de datos MongoDB se llama `sednight` y contiene las siguientes colecciones:

- **categories** - Categorias de productos
- **products** - Productos del minimarket
- **customers** - Clientes
- **sales** - Ventas realizadas

Todas las colecciones incluyen timestamps automaticos (createdAt, updatedAt).
